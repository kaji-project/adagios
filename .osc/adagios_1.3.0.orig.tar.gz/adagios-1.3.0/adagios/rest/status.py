# This is a wrapper around the rest functionality that exists in
# The status view. We like to keep the actual implementations there
# because we like to keep code close to its apps
from adagios.status.rest import *
